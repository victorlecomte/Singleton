class classeA {

private:
    classeA();

public:
static classeA* instance;

static classeA* getInstance();
int nombre;
};
