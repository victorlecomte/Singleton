#include "classeA.h"
classeA* classeA::instance=0;
classeA::classeA() { nombre=132;}

classeA* classeA::getInstance(){
if (instance ==0){
    instance = new classeA();
}
return instance;
}
