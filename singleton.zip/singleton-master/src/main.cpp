#include "classeA.h"
#include <iostream>

int main() {

classeA* premier = classeA::getInstance();
classeA* second = classeA::getInstance();

std::cout << second -> nombre << std::endl;
return 0;
}
