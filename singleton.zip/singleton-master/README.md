# Singleton

C'est un singleton 